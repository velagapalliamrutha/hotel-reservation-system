# 🏨 Hotel Reservation System – Java

A simple hotel booking and room management application built using Java (Core + OOP).  
The system allows customers to book rooms, view available rooms, check pricing, cancel reservations, and generate bill amounts instantly.

## ✨ Features
- View available rooms
- Book room with name & stay duration
- View all current reservations
- Cancel bookings anytime
- Auto bill calculation

## 🚀 How to Run
javac HotelReservationSystem.java
java HotelReservationSystem

Enjoy coding! 🔥
