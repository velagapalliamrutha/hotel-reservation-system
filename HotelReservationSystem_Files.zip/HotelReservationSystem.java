import java.util.ArrayList;
import java.util.Scanner;

class Room {
    int roomNumber;
    String type;
    double price;
    boolean isBooked;

    Room(int roomNumber, String type, double price) {
        this.roomNumber = roomNumber;
        this.type = type;
        this.price = price;
        this.isBooked = false;
    }
}

class Reservation {
    String customerName;
    int roomNumber;
    int days;
    double bill;

    Reservation(String customerName, int roomNumber, int days, double bill) {
        this.customerName = customerName;
        this.roomNumber = roomNumber;
        this.days = days;
        this.bill = bill;
    }
}

public class HotelReservationSystem {
    static ArrayList<Room> rooms = new ArrayList<>();
    static ArrayList<Reservation> reservations = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        defaultRooms();
        int choice;

        do {
            System.out.println("\n====== HOTEL RESERVATION SYSTEM ======");
            System.out.println("1. View Available Rooms");
            System.out.println("2. Book a Room");
            System.out.println("3. View Reservations");
            System.out.println("4. Cancel Reservation");
            System.out.println("5. Exit");
            System.out.print("Enter Choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> viewAvailableRooms();
                case 2 -> bookRoom();
                case 3 -> viewReservations();
                case 4 -> cancelReservation();
                case 5 -> System.out.println("Thank you for using the system. Goodbye!");
                default -> System.out.println("Invalid Choice!");
            }
        } while (choice != 5);
    }

    static void defaultRooms() {
        rooms.add(new Room(101, "Single Bed", 1500));
        rooms.add(new Room(102, "Double Bed", 2200));
        rooms.add(new Room(103, "AC Deluxe", 3000));
        rooms.add(new Room(104, "Luxury Suite", 4500));
    }

    static void viewAvailableRooms() {
        System.out.println("\n--- Available Rooms ---");
        for (Room room : rooms) {
            if (!room.isBooked) {
                System.out.println("Room " + room.roomNumber + " | " + room.type + " | ₹" + room.price + "/day");
            }
        }
    }

    static void bookRoom() {
        System.out.print("\nEnter Customer Name: ");
        sc.nextLine();
        String name = sc.nextLine();

        viewAvailableRooms();
        System.out.print("Enter Room Number to Book: ");
        int roomNo = sc.nextInt();
        System.out.print("Enter Number of Days: ");
        int days = sc.nextInt();

        Room selected = null;
        for (Room room : rooms) {
            if (room.roomNumber == roomNo && !room.isBooked) {
                selected = room;
                room.isBooked = true;
                break;
            }
        }

        if (selected == null) {
            System.out.println("Room not available!");
            return;
        }

        double bill = selected.price * days;
        reservations.add(new Reservation(name, roomNo, days, bill));
        System.out.println("\nRoom Booked Successfully!");
        System.out.println("Total Bill: ₹" + bill);
    }

    static void viewReservations() {
        System.out.println("\n--- Current Bookings ---");
        for (Reservation r : reservations) {
            System.out.println("Name: " + r.customerName + " | Room: " + r.roomNumber 
            + " | Days: " + r.days + " | Bill: ₹" + r.bill);
        }
    }

    static void cancelReservation() {
        System.out.print("\nEnter Room Number to Cancel Booking: ");
        int roomNo = sc.nextInt();

        Reservation removeRes = null;
        for (Reservation r : reservations) {
            if (r.roomNumber == roomNo) {
                removeRes = r;
                break;
            }
        }

        if (removeRes != null) {
            reservations.remove(removeRes);
            for (Room room : rooms) {
                if (room.roomNumber == roomNo) {
                    room.isBooked = false;
                }
            }
            System.out.println("Reservation Cancelled Successfully!");
        } else {
            System.out.println("No booking found for that room.");
        }
    }
}